###Effects without using permutations and without paired studies

#Imputation of missing values
Meta.impute<-function(x,y){
  index.miss<-which(sapply(x,function(y)any(is.na(y[[1]]))))
  ng<-nrow(x[[1]][[1]])
  gene.names<-row.names(x[[1]][[1]])
  miss.gene<-NULL
  if(length(index.miss)>0){
    require(impute)
    for(j in index.miss){
      k<-ncol(x[[j]][[1]])
      rnum<-which(apply(x[[j]][[1]],1,function(y) sum(is.na(y))/k)<y)
      x[[j]][[1]][rnum,]<-impute.knn(x[[j]][[1]][rnum,],k=10)$data
      miss.gene<-c(miss.gene,gene.names[-rnum])       
    }
    cat("gene:",unique(miss.gene),"will not be analyzed due to >",y,"missing\n")
  }
  return(x)
}


#Functions for calculating effects size
get.ES<-function(x){   
  K<-length(x) 
  ES.m<-Var.m<- N<-n<-NULL  
  for (k in 1:K){
    y<-x[[k]][[1]]
    l<-x[[k]][[2]]
    temp<-cal.ES(y,l)
    ES.m<-cbind(ES.m,temp[,"dprime"])
    Var.m<-cbind(Var.m,temp[,"vardprime"])
    N<-c(N,length(l))
    n<-c(n,table(l))
  }
  rownames(ES.m)<-rownames(y)
  rownames(Var.m)<-rownames(y)
  colnames(ES.m)<-paste("study",1:K,sep="")
  colnames(Var.m)<-paste("study",1:K,sep="")
  res<-list(ES=ES.m,Var=Var.m)
  attr(res,"nperstudy")<-N
  attr(res,"nperlabelperstudy")<-n 
  return(res)	
}


cal.ES<-function(y,l){
  l<-unclass(factor(l))
  n<-table(factor(l))
    ind<-diag(rep(1,length(n)))[l,]
    ym<-y%*%ind%*%diag(1/n) 
    ntilde<-1/sum(1/n)
    m=sum(n)-2
    cm = cm<-1-(3/(4*sum(n)-9))
    s<-sqrt((1/(sum(n)-2)*((y^2%*%ind)%*%diag(1/(n-1))-ym^2%*%diag(n/(n-1)))%*%(n-1)))
    d<-(ym[,2]-ym[,1])/s
    dprime=d*cm
    terme1=1/ntilde
    vard<- (sum(l==1)^(-1)+sum(l==2)^(-1))+(d^2)/(2*(sum(l==1)+sum(l==2)))
    vardprime=sum(1/n)+dprime^2/(2*sum(n))			
  result = cbind( dprime, vardprime)
  colnames(result) = c( "dprime", "vardprime")
  rownames(result)<-rownames(y)
  result
}

#Function that combines the others for calculating effects size
ind.cal.ES<-function(x,miss.tol=0.3){
  x<-Meta.impute(x,y=miss.tol)
  K<-length(x)
  res<-get.ES(x)
  if(is.null(names(x))){colnames(res$ES)<-colnames(res$Var)<-paste("dataset",1:K,sep="")
  }else{colnames(res$ES)<-colnames(res$Var)<-names(x)}
  result<-list(ES=res$ES,Var=res$Var)
  attr(result,"nperstudy")<-attr(res,"nperstudy")
  attr(result,"nperlabelperstudy")<-attr(res,"nperlabelperstudy") 
  return(result)
}

#Models

#Fixed Effects Model (FEM)
get.FEM<-function(em,vm){
  wt<-1/vm
  mu.hat<-rowSums(wt*em)/rowSums(wt)
  mu.var<-1/rowSums(wt)
  z.score<-mu.hat/sqrt(mu.var)
  z.p<-2*(1-pnorm(abs(z.score)))
  qval<-p.adjust(z.p,method="BH")
  res<-list(mu.hat=mu.hat,mu.var=mu.var,
            zval=z.score,pval=z.p,FDR=qval)
  return(res)
}


#RANDOM Effects Model (REM)

#Obtaining the Q that represents the total variance
get.Q<-function(em,vm){
  wt <- 1/vm
  temp1 <- wt * em
  mu.hat <- rowSums(temp1)/rowSums(wt)
  Q <- rowSums(wt * (em - mu.hat)^2)
  return(Q)
}

#Obtaining variance between studies
get.tau2<-function(Q,vm,k){
  wt<-1/vm
  s1 <- rowSums(wt)
  s2 <- rowSums(wt^2)
  temp<- (Q - (k - 1))/(s1 - (s2/s1))
  tau2<-pmax(temp,0)
  return(tau2)
}

#Calculating the model
get.REM<-function(em,vm){
  k<-ncol(em)
  Q.val<-get.Q(em,vm) #Total variance
  tau2<-get.tau2(Q.val,vm,k) #Varianza between studies
  temp.wt<-1/(vm+tau2)	#weight assigned to each study
  mu.hat<-rowSums(temp.wt*em)/rowSums(temp.wt)
  mu.var<-1/rowSums(temp.wt)
  Qpval <- pchisq(Q.val, df = k - 1, lower.tail = FALSE)
  z.score<-mu.hat/sqrt(mu.var)
  z.p<-2*(1-pnorm(abs(z.score)))
  qval<-p.adjust(z.p,method="BH")
  res<-list(mu.hat=mu.hat,mu.var=mu.var,Qval=Q.val,Qpval=Qpval,tau2=tau2,zval=z.score,pval=z.p,FDR=qval)
  return(res)
}

##############
#Function that combines function of both methods
Meta.ES<-function(x,meta.method=c("FEM","REM")){
  meta.method<-match.arg(meta.method)
  K<-ncol(x$ES)
  if(meta.method=="REM"){ #Random effects model
    res<-get.REM(x$ES,x$Var)
    tempFDR<-matrix(res$FDR,ncol=1)
    rownames(tempFDR)<-rownames(x$ES)
    colnames(tempFDR)<-meta.method
    meta.res<-list(mu.hat=res$mu.hat,mu.var=res$mu.var,Qval=res$Qval,Qpval=res$Qpval,tau2=res$tau2,zval=res$zval,pval=res$pval,FDR=tempFDR)	
  }else{ #Fixed effects model
    res<-get.FEM(x$ES,x$Var)
    tempFDR<-matrix(res$FDR,ncol=1)
    rownames(tempFDR)<-rownames(x$ES)
    colnames(tempFDR)<-meta.method
    meta.res<-list(mu.hat=res$mu.hat,mu.var=res$mu.var,zval=res$zval,pval=res$pval,FDR=tempFDR)	
  }	
  attr(meta.res,"nstudy")<-K
  attr(meta.res,"meta.method")<-meta.method 
  class(meta.res)<-"Meta.ES"
  return(meta.res)
}


#INDIVIDUAL ANALYSIS
ind.analysis<-function(x){
  library(limma)
  numero<-length(x)
  p<-matrix(nrow = nrow(x[[1]][[1]]), ncol=(length(x)))
  rownames(p)<- rownames(x[[1]][[1]])
  FC<-matrix(nrow = nrow(x[[1]][[1]]), ncol=(length(x)))
  rownames(FC)<- rownames(x[[1]][[1]])
  #Prepaing data for indiviual analysis
  for(k in 1:numero){
    M<-x[[k]][[1]]
    Y<-x[[k]][[2]]
    design<-matrix(data=0,ncol=2,nrow=ncol(M))
    rownames(design)<-colnames(M)
    colnames(design)<-c("CONTROL","CASE")
    for(i in 1:length(Y)){
      if(Y[[i]]==1){
        design[i,1] = 0
        design[i,2] = 1
      }
      else{
        design[i,1]=1
        design[i,2]=0
      }
    }
    #Starting to use limma package
    fit <- lmFit(M, design)
    contrast.matrix <- makeContrasts(CASE-CONTROL, levels=design)
    fit2 <- contrasts.fit(fit, contrast.matrix)
    fit2 <- eBayes(fit2)
    limma<- topTable(fit2, coef=1, adjust="BH",number = nrow(M), sort.by = "none")
    pvalores<-limma$P.Value #Selecting pvalues obtained
    FoldChange<-limma$logFC
    p[,k]<-pvalores
    FC[,k] <- FoldChange
  }
  colnames(p)<-colnames(FC)<-names(x)
  resultP<-list(p=p, FC=FC)
  return(resultP)
}

#P-Values Combnation
library(metap)

#Fisher's Method
get.fisher<-function(p){
  stat<-res<-pval<-fdr<-0
  todos<-apply(p,1,sumlog) #metap package is used
  #Extraction of p-values of each one
  for(i in 1:nrow(p)){
    stat[i] <- todos[[i]]$chisq #Statistical
    pval[i]<-todos[[i]]$p #P-value combined
    fdr<- p.adjust(pval, method = "BH") #pvalor ajusted
  }
  res<-list(stat=stat, pval=pval, FDR=fdr)
  names(res$stat)<-names(res$pval)<-names(res$FDR)<-rownames(p)
  return(res)
}

#########################

#Stouffer's method
get.Stouff<- function(p){
  stat<-res<-pval<-fdr<-0
  todos<-apply(p,1,sumz) #metap package is used
  #Extraction of p-values of each one
  for(i in 1:nrow(p)){
    stat[i] <- todos[[i]]$z #Statistical
    pval[i]<-todos[[i]]$p #P-value combined
    fdr<- p.adjust(pval, method = "BH") #pvalor ajusted
  }
  res<-list(stat=stat, pval=pval, FDR=fdr)
  names(res$stat)<-names(res$pval)<-names(res$FDR)<-rownames(p)
  return(res)
}

##############################

#Minimun P method
get.minP<-function(p){
  stat<-res<-pval<-fdr<-0
  pval.all<-apply(p,1,minimump) #metap package is used
  stat<-apply(p,1,min) #Statistical
  #Extraction of p-values of each one
  for(i in 1:nrow(p)){
    pval[i]<-pval.all[[i]]$p #P-value combined
    fdr<- p.adjust(pval, method = "BH") #pvalor ajusted
  }
  res<-list(stat=stat, pval=pval, FDR=fdr)
  names(res$stat)<-names(res$pval)<-names(res$FDR)<-rownames(p)
  return(res)
}


###############################


#Maximun P value
get.maxP<- function(p){
  stat<-res<-pval<-fdr<-0
  pval.all<-apply(p,1,maximump) #metap package is used
  stat<-apply(p,1,max)
  #Extraction of p-values of each one
  for(i in 1:nrow(p)){
    pval[i]<-pval.all[[i]]$p #P-value combined
    fdr<- p.adjust(pval, method = "BH")#pvalor ajusted
  }
  res<-list(stat=stat, pval=pval, FDR=fdr)
  names(res$stat)<-names(res$pval)<-names(res$FDR)<-rownames(p)
  return(res)
}



#COMBINATION OF METHODS
Meta.pvalue <-function(resultP,meta.method=c("maxP","minP","Fisher",
                                             "Stouffer")){
  p<-resultP$p
  require(metap)
  K<-ncol(p)
  nm<-length(meta.method)
  meta.res<-list(stat=NA,pval=NA,FDR=NA)
  meta.res$stat<-meta.res$pval<-meta.res$FDR<-matrix(NA,nrow(p),nm)
  for( i in 1:nm){
    temp<-switch(meta.method[i],maxP={get.maxP(p)},
                 minP={get.minP(p)},
                 Fisher={get.fisher(p)},
                 Stouffer={get.Stouff(p)})
    meta.res$stat[,i]<-temp$stat
    meta.res$pval[,i]<-temp$pval
    meta.res$FDR[,i]<-temp$FDR
  }
  colnames(meta.res$stat)<-colnames(meta.res$pval)<-colnames(meta.res$FDR)<-meta.method
  rownames(meta.res$stat)<-rownames(meta.res$pval)<-rownames(meta.res$FDR)<-rownames(p)
  logFC<-matrix(rowMeans(resultP$FC, na.rm=T), ncol=1)
  colnames(logFC)<-c("-logFC")
  rownames(logFC) <- rownames(resultP$FC)
  attr(meta.res,"nstudy")<-K
  attr(meta.res,"meta.method")<-meta.method
  res<-list(meta.analysis=meta.res, logFC=logFC, ind.p=p, ind.logFC = resultP$FC)
  class(res)<-"Meta.pvalue"
  return(res)
}








