############################################################
## Centro Pfizer-Universidad de Granada-Junta de Andalucia de Genomica e Investigacion Oncologica (GENYO)
## July, 2018
############################################################
## 
############################################################
## Daniel.toro@genyo.es, Jordi.martorell@genyo.es, Pedro.carmona@genyo.es
############################################################
## Libraries needed
library("Biobase")
library("impute")
library("GEOquery")
library("limma")
library(scales)
library('survival')
library('impute')
library('combinat')
library('tools')

## READ AND CREATE ALL PARAMETERS NEEDED
source("./MetaMethods.R")
source("./ImaGEO_functions.R")
group1Name = "group1"
group2Name = "group2"
geoIDs=NULL   
cl=NULL
platform=NULL
met1=NULL
met2=NULL
threshold=NULL
selectBY=NULL
mydata.merged=NULL
RES=NULL
DE=NULL
destdir=getwd()
UPload=0

## Read Parameters file. This file contains parameters needed for the analysis (Methods, quality control variables, threshold criteria)
con<-file("parameters.txt")
open(con)
results.list <- list()    ## This list stores all parameters and now, the parameters must be save in independent variables
current.line <- 1
while (length(line <- readLines(con, n = 1, warn = FALSE)) > 0) { 	## This loop read the file
  results.list[[current.line]] <- unlist(strsplit(line, split=","))
  current.line <- current.line + 1
}
close(con)
rm(con,current.line,line)

## Save each parameter in independent variables
met1<-results.list[[1]]		## met1 stores the method selected to do the meta-analysis (by pvalue or by effect size)
if(met1=="ES"){
  met2<-results.list[[3]]
}else{
  met2<-results.list[[2]]		## met2 stores the concret method to do the meta-analysis (REM, FEM, Fisher, etc)
}
pc<-as.numeric(results.list[[4]])     ## pc is the percentage of missing values allowed in the analysis. Generally, 10 or 15 percent is allowed
threshold<-as.numeric(results.list[[5]]) ## threshold selected for the analyisis
selectBY<-results.list[[6]]		## pvalue or corrected pvalue is taken into account to sorted the results.

if(file.exists("samples.txt")==TRUE){ ## NUEVO

## Read class assignation of each sample.
con2<-file(paste0("samples.txt")) 
open(con2);
results.list2 <- list();    ## This list stores all parameters and now, the parameters must be save in independent variables
current.line <- 1
while (length(line <- readLines(con2, n = 1, warn = FALSE)) > 0) { 	## This loop read the file
  results.list2[[current.line]] <- unlist(strsplit(line, split=" "))
  current.line <- current.line + 1
}
close(con2)
rm(con2,current.line,line)

geoIDs<-as.character(results.list2[[1]])   ## geoIDs stores the GEO identifiers selected to do the meta-analysis
platform<-as.character(results.list2[[2]])   ## platform selected for each data set
cl<-results.list2[3:length(results.list2)] ## Class vectors of each data set selected (0=control, 1=case, "x"=sample removed)

## Remove datasets without samples selected
functionSamples = function(x) {
  if(length(unique(x)) == 1) {
      if (unique(x) == "x") {
        return(FALSE)
      }
    else {
      return(TRUE)
    }
  }
  else {
    return(TRUE)
  }
}
withSamples <- sapply(cl, functionSamples)
geoIDs <- geoIDs[withSamples]
platform <- platform[withSamples]
cl <- cl[withSamples]

## Load dataset required
for(i in 1:length(geoIDs)){
  geo2Meta(geoIDs[i],destdir=destdir,platform=platform[i],cl=cl[[i]]) ## Download datasets and create matrix of information 		
}  

} ## NUEVO

if(file.exists("DataSelf.txt")==TRUE){  ## To Upload local datasets 

  ## Read parameters
  nameData<-read.table("DataSelf.txt",sep=",",header=FALSE)
  n<-0
  for(i in 1: dim(nameData)[2]){
    x<-as.character(nameData[1,i])
    n<-c(n,x)
  }
  nameData<-n[-1]
  
  plat<-read.table("PlatSelf.txt",sep=",",header=FALSE)
  pp<-0
  for(i in 1: dim(plat)[2]){
    x<-as.character(plat[1,i])
    pp<-c(pp,x)
  }
  plat<-pp[-1]
  
  ## Create processed datasets in correct format
  ## NUEVO
  if(file.exists("samples.txt")==TRUE){
  geoIDs<-UpSelf(nameData,plat,geoIDs)
  }else{
    geoIDs<-1
    geoIDs<-UpSelf(nameData,plat,geoIDs)
    geoIDs<-geoIDs[-1]
  }
}

## Processing of the data	 
mydata.merged<-ProData(geoIDs) 
	
## Quality Control of the data
print("Performing Quality control analysis")
mydata.merged<-QCdata(mydata.merged,pc,geoIDs) 

## Meta-analysis of DE
print("Performing meta-analysis")
DE<-META.ANALYSIS(mydata.merged=mydata.merged,geoIDs=geoIDs,met1,met2,pc)  ## DE is a list. This format is necessary for SaveData function 
	
## Save file results
print("Saving results in local folder")
RES<-SaveData(met1,met2,DE,threshold)





