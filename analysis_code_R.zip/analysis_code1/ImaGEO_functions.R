############################################################
## Functions and libraries for ImaGEO
## Centro Pfizer-Universidad de Granada-Junta de Andalucia de Genomica e Investigacion Oncologica (GENYO)
## Last realase: April 2019
############################################################
## R version 3.3.2 
############################################################
## Daniel.toro@genyo.es, Jordi.martorell@genyo.es, Raul.lopez@genyo.es, Pedro.carmona@genyo.es
############################################################

 
############################################################   

geo2Meta <- function(
# Retrieve a data from GEO and format it for MetaDE package
# Output: IDs in the first column and Gene Symbol in the second column. 
  geoID,            # GEO Id for series name (Name among "", for example: "GSE10325")
  destdir,          # Directory in which soft files are downloaded locally, acts as a cache system 
  platform=NULL,    # platform: If series have more than one platform indicates the platform ID
  cl			    # class vector. Samples to be eliminates are labelled with "X"
  ){       
           
  gset <- getGEO(geoID, GSEMatrix =TRUE, destdir=destdir, getGPL = FALSE) 			 # Download datasets selected using getGEO
  if (length(gset) > 1) idx <- grep(platform, attr(gset, "names")) else idx <- 1  # Select platform
  gset <- gset[[idx]]
   
  # Check errors in group/class sample selection
  if(length(cl)==dim(gset)[2]){  
  	sel <- which(cl != "x"); cl <- cl[sel]; checkClass = unique(cl)  # eliminate samples marked as "X" (not selected in web interface)
  	
  	if (length(checkClass) == 2){ # One sample for each group/class must be selected as minimum
    	gset <- gset[ ,sel]                                                                              
    	# log2 transform (adapted from GEO2R)
    	ex <- exprs(gset)
    	qx <- as.numeric(quantile(ex, c(0., 0.25, 0.5, 0.75, 0.99, 1.0), na.rm=T))
    	LogC <- (qx[5] > 100) ||(qx[6]-qx[1] > 50 && qx[2] > 0) ||(qx[2] > 0 && qx[2] < 1 && qx[4] > 1 && qx[4] < 2)
    	if (LogC) { ex[which(ex <= 0)] <- NaN
    		exprs(gset) <- log2(ex) }
    	data<-as.data.frame(exprs(gset)); data$ID<-row.names(data)   # Creates data frame 
  
    	# Get platform annotation    
    	gpl <- annotation(gset)
    	annot <- read.delim(paste0(gpl, ".txt"))
    	ids_eg <- data.frame(ID = annot[,1], Symbol = annot[,2])

    
    	data <- merge(data, ids_eg, by="ID")  # Merge Gene Symbol ID with gene expression matrix
  
    	rownames(data)<-data[,1]; data[,1]<-data[,dim(data)[2]]; data<-data[,-dim(data)[2]]  # Format data for metaDE
		  data<-data[data$ID!="",]; data<-data[is.na(data$ID)!=TRUE,]  # Processing of Missing values in entrez gene ID
    	GSEclass <- c("NA",cl); GSE1<-rbind(GSEclass,data); GSE1<-as.matrix(GSE1)  # Format data for metaDE
    	write.table(GSE1,paste0(geoID,".txt"),sep="\t", quote = F)   # Save matrix on server folder
    	return()
    } 
  } else {  # Give error and stop the analysis
    print(paste0("Error in sample selection for ",geoID,sep=""," dataset"))
    errors<-c(paste0("ERROR: In ",geoID,sep="",", You haven't selected two groups of samples. No file created"))
    write(errors,paste0("ERROR.txt"),sep="\n",append=TRUE)    # Save error report
    return()
  }
}

##################################################################

##################################################################
MetaDE.Read2 <- function (filenames, via = c("txt", "csv"), skip, matched = FALSE, 
          log = TRUE) 
{
  K <- length(filenames)
  if (matched) {
    expdata <- list()
    for (i in 1:K) {
      if (via == "txt") {
        raw <- read.delim(paste(filenames[i], ".txt", 
                                sep = ""), sep = "\t", header = T, row.names = 1)
      }
      else {
        raw <- read.csv(paste(filenames[i], ".csv", sep = ""), 
                        header = T, row.names = 1)
      }
      if (log) {
        exprs <- as.matrix(raw[-(1:skip[i]), ])
        rownames(exprs) <- (rownames(raw))[-(1:skip[i])]
        exprs[exprs <= 0] <- 1
        exprs <- log2(exprs)
      }
      else {
        exprs <- as.matrix(raw[-(1:skip[i]), ])
        rownames(exprs) <- (rownames(raw))[-(1:skip[i])]
      }
      if (skip[i] == 1) {
        y <- as.numeric(raw[skip[i], ])
        expdata[[i]] <- list(x = as.matrix(exprs), y = y)
      }
      else {
        y <- as.numeric(raw[1, ])
        censoring.status <- as.numeric(raw[2, ])
        expdata[[i]] <- list(x = as.matrix(exprs), y = y, 
                             censoring.status = censoring.status)
      }
    }
    names(expdata) <- filenames
  }
  else {
    expdata <- list()
    for (i in 1:K) {
      if (via == "txt") {
        raw <- read.delim(paste(filenames[i], ".txt", 
                                sep = ""), sep = "\t", header = T, row.names = 1)
      }
      else {
        raw <- read.csv(paste(filenames[i], ".csv", sep = ""), 
                        header = T, row.names = 1)
      }
      if (log) {
        exprs <- as.matrix(raw[-(1:skip[i]), -1])
        rownames(exprs) <- (rownames(raw))[-(1:skip[i])]
        exprs[exprs <= 0] <- 1
        exprs <- log2(exprs)
      }
      else {
        exprs <- as.matrix(raw[-(1:skip[i]), -1])
        rownames(exprs) <- (rownames(raw))[-(1:skip[i])]
      }
      if (skip[i] == 1) {
        y <- as.numeric(raw[skip[i], -1])
        symbol <- (raw[-(1:skip[i]), 1])
        expdata[[i]] <- list(x = as.matrix(exprs), y = y, 
                             symbol = symbol)
      }
      else {
        y <- as.numeric(raw[1, -1])
        censoring.status <- as.numeric(raw[2, -1])
        symbol <- (raw[-(1:skip[i]), 1])
        expdata[[i]] <- list(x = as.matrix(exprs), y = y, 
                             censoring.status = censoring.status, symbol = symbol)
      }
    }
    names(expdata) <- filenames
  }
  return(expdata)
}

MetaDE.match2 <- function (x, pool.replicate = c("average", "IQR")) 
{
  pool.replicate <- match.arg(pool.replicate)
  K <- length(x)
  expdata <- list()
  for (i in 1:K) {
    temp <- list()
    temp$x <- x[[i]]$x
    temp$y <- x[[i]]$y
    temp$symbol <- x[[i]]$symbol
    tempRes <- Match.gene2(temp, pool.replicate = pool.replicate)
    expdata[[i]] <- tempRes
  }
  names(expdata) <- names(x)
  return(expdata)
}


Match.gene2<-function(x,pool.replicate=c("average","IQR")){
  require(tools)
  require(Biobase)
  pool.replicate<-match.arg(pool.replicate) 
  exprs_data<-x[[1]]
  symbol<-(x$symbol)
  if (pool.replicate=="average") {
    mean.f<-function(x){x<-as.data.frame(x)
    meanV<-apply(x,2,mean,na.rm=T)
    return(meanV)
    }
    
    D<-split(as.data.frame(exprs_data),as.factor(symbol))
    exprs2<-t(sapply(D,function(x)mean.f(x)))
    exprs3<-t(apply(exprs2,1,unlist))
    rownames(exprs3)<-names(D)
    
  } 
  else{
    IQR.f<-function(x){x<-as.data.frame(x)
    IQRS<-apply(x,1,IQR,na.rm=T)
    temp.index<-which.max(IQRS)
    return(x[temp.index,])
    }
    
    D<-split(as.data.frame(exprs_data),as.factor(symbol))
    exprs2<-t(sapply(D,function(x)IQR.f(x)))
    exprs3<-t(apply(exprs2,1,unlist))
    rownames(exprs3)<-names(D)
  }
  colnames(exprs3)<-colnames(x$data)
  if(is.null(x$censoring)){
    res<-list(x=exprs3,y=x[[2]])
  }else{res=list(x=exprs3,y=x[[2]],censorsing.status=x$censoring.status)}
  return(res)
}

MetaDE.merge2 <- function (x, MVperc = 0) 
{
  x.symbol <- lapply(x, function(y) (rownames(y[[1]])))
  id.count <- table(unlist(x.symbol))
  n <- length(x.symbol)
  common.id <- names(which(id.count >= (1 - MVperc) * n))
  match.id <- function(study) {
    exprs <- study
    id <- rownames(exprs)
    diff.id <- setdiff(common.id, id)
    n.sample <- ncol(exprs)
    margin.na <- matrix(NA, ncol = n.sample, nrow = length(diff.id))
    colnames(margin.na) <- colnames(exprs)
    rownames(margin.na) <- diff.id
    exprs <- rbind(exprs, margin.na)
    index <- match(common.id, rownames(exprs))
    exprs2 <- exprs[index, ]
    return(exprs2)
  }
  K <- length(x)
  for (i in 1:K) {
    x[[i]][[1]] <- match.id(x[[i]][[1]])
  }
  return(x)
}
###################################################################

###################################################################

ProData<-function (  
# For processing data. The Input is a vector with GEO IDs selected
# The Output is a list with processed data
  geoIDs){           # vector with geoIDs used
         
  for (id in geoIDs){
    file = grep(paste0("^", id, ".t"), list.files(), value=T)
    system(paste("mv", file, paste0(id, ".txt")))
  }
  mydata<-MetaDE.Read2(geoIDs,via="txt",skip=rep(1,length(geoIDs)),log=TRUE)  # Read all expression sets from server folder                             
  
  mydata.matched<-try(MetaDE.match2(mydata,"IQR"))  #  Average genes with MetaDE.match. Slow process
  if (class(mydata.matched) == "try-error"){
    mydata.matched<-MetaDE.match2(mydata,"average") #  Slow process
  }
  mydata.merged<-MetaDE.merge2(mydata.matched)      #  Merge Datasets with MetaDE.merge
  return(mydata.merged) 						   #  mydata.merged contains all expression sets from datasets selected in a united list, the duplicated ID have been mediated
}
##################################################################

##################################################################

QCdata<-function(
# To make a Quality control of the selected datasets. QCdata performs a control of missing values
  mydata.merged,        # List whit all datasets
  pc,					# Percentage of Missing values allowed
  geoIDs				# vector with geoIDs used
  ){

 SummaryQC<-matrix(data=0,ncol=4,nrow=length(mydata.merged)); SummaryQC<-as.data.frame(SummaryQC) # Store the information of the pre- and post- quality control
 colnames(SummaryQC)<-c("ID","Samples_preQC","Samples_postQC","Imputed_Genes")

 check.remove<-0    					# If a complete datasets fail the missing value threshold, it is store in this object to remove the complete dataset then
 for(i in 1:length(mydata.merged)){  # Loop for plotting all datasets included in the study
  	ind.data<-mydata.merged[[i]]$x  # ind.data stores a individual dataset (all datasets are contained in mydata.merged)
 	cl<-mydata.merged[[i]]$y  		# cl store the vector of classes of a concret dataset
 
 ## Quality Control for Samples:
	NAplot<-matrix(data=0,ncol=dim(ind.data)[2],nrow=2)  # NAplot stores the information for missing values plot
  	rownames(NAplot)<-c("X_axes","NA"); NAplot[1,]<-1:dim(ind.data)[2]
	 
	sampl.control<-0  									 # Used to mark not suitable samples
 	for(j in 1:dim(ind.data)[2]){ 
  		n.na<-length(which(is.na(ind.data[,j]))); n.na<-n.na/dim(ind.data)[1]  # To calculate the number of missing values per columns (samples)
  		NAplot[2,j]<-n.na 								 # Save the number of missing values of each column in NAplot (the rows represent the samples)
		if(n.na>pc){  sampl.control<-c(sampl.control,j)} # In sampl.control is stored the possition of columns that have more of "pc" (percent) of missing values
	}
	sampl.control<-sampl.control[-1]
	

 	
	SummaryQC[i,1]<-geoIDs[i]; SummaryQC[i,2]<-dim(ind.data)[2]       # Store the information of the pre- and post- quality control
	if(length(sampl.control)>0){
		ind.data<-ind.data[,-(sampl.control)]; cl<-cl[-sampl.control] # Remove not suitable samples
	}
	SummaryQC[i,3]<-dim(ind.data)[2] 								  # Store the information of the pre- and post- quality control

 ## Quality Control for Genes:
	enter = TRUE
	TEST.na<-ind.data[!complete.cases(ind.data),] # Select the rows/genes with missing values
	if (!is.null(nrow(TEST.na))){
		if (nrow(TEST.na) == 0){
			enter=FALSE        # if enter take FALSE value, there are not missing values in any rows/genes
		}
	}
	if(enter == TRUE){  	   						 # enter = TRUE denotes that there are missing values that must be imputed
		# Imputation of the remaining NA values 
		control.means<-ind.data[,which(cl==0)] 		 # table of samples from group/class 1
		case.means<-ind.data[,which(cl==1)]			 # table of samples from group/class 2
		ind.data<-cbind(ind.data,1:dim(ind.data)[1]) # Add indexer for gene position into the ind.data file
		if (ncol(as.matrix(TEST.na)) == 1){   		 ##PROBAR CUANDO SOLO HAY UNA COLUMNA DE NA
			vect.na<-t(as.matrix(ind.data[!complete.cases(ind.data),]))
		} else {
			vect.na<-as.matrix(ind.data[!complete.cases(ind.data),])
		}
		rm(TEST.na)
		ind.data<-ind.data[,-(dim(ind.data)[2])]     # Remove indexer for gene position into the ind.data file, it is located in vect.na
		vect.na<-as.numeric(vect.na[,dim(vect.na)[2]])
		SummaryQC[i,4]<-length(vect.na)

		for(g in 1:length(vect.na)){  	
			hmean<-mean(control.means[vect.na[g],],na.rm=TRUE) # Mean of group1 to impute missing values
			if(is.na(hmean)){
				hmean<-mean(control.means,na.rm=TRUE)  		   # If the genes have not data, the values were extrapolated from all gruup1 genes
			}
			cmean<-mean(case.means[vect.na[g],],na.rm=TRUE)	   # Mean of group2 to impute missing values
			if(is.na(cmean)){
				cmean<-mean(case.means,na.rm=TRUE)  		   # If the genes have not data, the values were extrapolated from all gruup2 genes
			}
				for(col in 1:dim(ind.data)[2]){
					if(is.na(ind.data[vect.na[g],col])==TRUE && cl[col]==1){ # Missing value takes the mean value of the row/genes of Group2 
						ind.data[vect.na[g],col]<-cmean
					}
					if(is.na(ind.data[vect.na[g],col])==TRUE && cl[col]==0){ # Missing value takes the mean value of the row/genes of Group1 
						ind.data[vect.na[g],col]<-hmean
					}
				}
		}
	} else {
		SummaryQC[i,4]<-0  # No misssing values in rows/genes
	}
	mydata.merged[[i]]$x<-ind.data; mydata.merged[[i]]$y<-cl   # Save the postQC data into mydata.merged		

	if((dim(ind.data)[1]==0)||(dim(ind.data)[2]==0)){ ## Check if some dataset is completely removed
		check.remove<-c(check.remove,i)
	}
 }
 if(length(check.remove)>1){ # Remove complete wrong datasets
	check.remove<-check.remove[-1]
	for(ck in length(check.remove):1){
		mydata.merged<-mydata.merged[-(check.remove[ck])]; geoIDs<-geoIDs[-(check.remove[ck])]
	}
 }
 if(length(geoIDs)<=1){ 	 # Check if only one dataset is suitable for the meta-analysis (The other have been removed completelly in the Quality Control Step
	afileE<-paste0("ERROR: Only one dataset is suitable for the meta-analysis: ",sep="",geoIDs)
	write(afileE,paste0("ERROR.txt"),sep="\n",append=TRUE)
 }
 write.table(SummaryQC,paste0("QC_information.txt"),sep="\t",row.names=FALSE, quote = F) # Write information into the summary table
 return(mydata.merged)  	 #  mydata.merged contains all expression sets from datasets selected with Quality control performed to genes and samples
}
##################################################################

##################################################################

META.ANALYSIS<-function(     
# To perform meta-analysis chosen
# The Output is a list with meta-analysis results
  mydata.merged,             # Output of ProData
  geoIDs,                    # vector with geoIDs used
  met1=NULL,                 # "ES" or "PVALUE"
  met2=NULL,                 # Meta-analysis method chosen
  pc=NULL){                  # Percentage of missing values. 0.1% by default

  	# To chose the meta-analysis method
  	if (met1=="ES"){
  		DE<-ESMA(mydata.merged,geoIDs,met2,pc)  # Meta-analysis by effect size
  	}
  	if (met1=="PVALUE"){
  		DE<-PVMA(mydata.merged,geoIDs,met2,pc)  # Meta-analysis by p-value
  	}
  return(DE)	 # Meta-analysis result object
}
##################################################################

##################################################################

ESMA<-function(  
# To perform Effect Size meta-analysis
# Output is DE file that contains the results of this meta-analysis
  mydata.merged, # Output of ProData
  geoIDs,        # Vector with geoIDs used
  met2,          # ES Method chosen: "FEM" or "REM"
  pc){           # Percentage of missing values allowed

  ind.res<-ind.cal.ES(mydata.merged,miss.tol=pc) # Find differentially expressed genes
  DE<-Meta.ES(ind.res,meta.method=met2)  # Perform the Meta-analysis
  return(DE)	 # Meta-analysis result object
}
##################################################################

##################################################################

PVMA<-function(  
# To perform Pvalue meta-analysis
# Output is DE file that contains the results of this meta-analysis
  mydata.merged, # Output of ProData
  geoIDs,        # Vector with geoIDs used
  met2,          # Pvalue Method chosen: "maxP","minP","Fisher","AW","Stouffer","SR" or "PR"
  pc){           # Percentage of missing values allowed
  
         
  ind.res<-ind.analysis(mydata.merged) # Find differentially expressed genes
  DE<-Meta.pvalue(ind.res,meta.method=met2) # Perform the Meta-analysis
 
  DE<-foldP(mydata.merged,DE)  # Calculate the fold changes using limma package
  
  # P valor sin corregir
  # ind.res0<-ind.analysis(mydata.merged,ind.method=rep("pearsonr",length(geoIDs)),nperm=250,miss.tol=pc,tail="abs") # Find differentially expressed genes
  # DE0<-MetaDE.pvalue(ind.res0,meta.method=met2) # Perform the Meta-analysis
  # 
  # DE[["meta.analysis_0"]] = DE0$meta.analysis
  return(DE)	 # Meta-analysis result object
}
##################################################################

##################################################################

foldP<-function(      
# To calculate Fold Change with limma
  mydata.merged,        # Output of ProData
  DE){                  # Meta-analysis result file

  # Create a matrix with all normalized samples
  all.data<-matrix(data=0,ncol=2,nrow=dim(mydata.merged[[1]]$x)[1]) ## all.data is a matrix with all datasets selected included
  all.data<-as.data.frame(all.data)
  classn<-1; datasetNum<-1; sampleNum<-1; 	# classn: class/group assignation for all samples selected; datasetNum: order of datasets included in mydata.merged; sampleNum: order of samples into each dataset
  for(i in 1:length(mydata.merged)){
  	vect<-1
  	ind.data<-mydata.merged[[i]]$x			# Expression data from dataset i
  	classn<-c(classn,mydata.merged[[i]]$y)  # Class/group assignation for samples from dataset i
  	datasetNum<-i
  	for(j in 1:dim(ind.data)[2]){ 			# To rename colnames of each dataset
  		sampleNum<-j
  		vect<-c(vect,paste(datasetNum,sep=".",sampleNum))  # New sample names 
  	}
  	vect<-vect[-1]; colnames(ind.data)<-vect			   # Rename colnames of each dataset
  	all.data<-cbind(all.data,ind.data)		# Merge each dataset sequentially
  }
  all.data<-all.data[,-(1:2)]; classn<-classn[-1]  
  
  # Calculate the fold change using limma package
  design<-matrix(data=0,ncol=2,nrow=dim(all.data)[2])      # Create design matrix
  colnames(design)<-c("Group_1","Group_2");  rownames(design)<-colnames(all.data)
  for(i in 1:dim(design)[1]){
  	if(classn[i]==1){
  		design[i,2]<-1
  	}else{
  		design[i,1]<-1
  	}
  }
  fit <- lmFit(all.data, design) 						   # Run limma
  cont.matrix <- makeContrasts(Group_2-Group_1, levels=design)
  fit2 <- contrasts.fit(fit, cont.matrix); fit2 <- eBayes(fit2, 0.05)
  limma <- topTable(fit2, adjust="fdr", sort.by="none", number=dim(all.data)[1])
 
  limma<-cbind(rownames(limma),limma); colnames(limma)[1:2]<-c("ID","FoldChange")
  description<-"Limma results of datasets used. Limma package has been used for calculate the fold changes of each gene"
  #  Merge limma results and DE results
  limmalist<-list(limma,description)
  names(limmalist)<-c("limma","description")
  DE<-c(DE,limmalist)  ## DE is a list. This format is necessary for SaveData function 
  return(DE)
}
##################################################################

##################################################################

SaveData<-function(     
# Save results files 
# The Output is a data.frame with ordered data results
  met1,                  # "ES" or "PVALUE" method chosen
  met2,                 # Meta-analysis method chosen
  DE,                   # Meta-analysis result file
  threshold
  ){             
  

## Save results of effect size meta-analysis
  if(met1=="ES"){

    RES<-as.data.frame(DE$FDR)
    RES<-cbind(RES,DE$pval); RES<-cbind(RES,DE$zval); RES<-cbind(RES,rownames(RES)) # Select results of meta-analysis (DE)
    if (met2 == "REM"){
      RES<-cbind(RES,DE$Qval); RES<-cbind(RES,DE$Qpval); RES<-cbind(RES,DE$tau2)
      colnames(RES)<-c("fdr_pval","pval","zval","ID","Qval","Qpval","tau2")
    } else {
      colnames(RES)<-c("fdr_pval","pval","zval","ID")
    }
    
    GeneSym<-read.delim(paste0("./GeneSymbol_", "MATCH.txt"),sep="\t",header=TRUE)
    GeneSym<-GeneSym[,1:2]
    RES_ID2<-merge(RES,GeneSym,by="ID",all.x=TRUE)
    write.table(RES_ID2,paste0("All_genes_results.txt"),sep="\t",row.names=FALSE, quote = F) # Save all results
  
	RES<-RES[complete.cases(RES), ]	# Remove rows with missing values
  	RES<-RES[RES$fdr_pval<=threshold,] # Filter genes by p value threshold
  	up<-RES[RES$zval>0,]			# Create a matrix with up-expressed genes
  	if (nrow(up) > 0){  			
    	up2 = up
    	up2[,4] = as.character(up2[,4])
    	genes.sep.up =  strsplit(up2[,4], "///", fixed = T)
    	for (line in 1:length(up2[,4])){
    	  if (length(genes.sep.up[[line]]) > 1){
    	    if (!grepl("-", genes.sep.up[[line]][1], fixed = T) && !grepl("LOC", genes.sep.up[[line]][1], fixed = T)){
    	      up2[line,4] = genes.sep.up[[line]][1]
    	    }
    	    else{
    	      up2[line,4] = genes.sep.up[[line]][2]
    	    }
    	  }
    	}
    	num_up<-dim(up)[1]
    	desc<-c(rep("over_expressed",num_up))  # desc stores information of fold changes of each gene
    	up<-cbind(up,desc); colnames(up)[dim(up)[2]]<-"Description"
  }
  	
  	down<-RES[RES$zval<0,]			 # Create a matrix with down-expressed genes
  	if (nrow(down) > 0){
    	down2 = down
    	down2[,4] = as.character(down2[,4])
    	genes.sep.down =  strsplit(down2[,4], "///", fixed = T)
    	for (line in 1:length(down2[,4])){
    	  if (length(genes.sep.down[[line]]) > 1){
    	    if (!grepl("-", genes.sep.down[[line]][1], fixed = T) && !grepl("LOC", genes.sep.down[[line]][1], fixed = T)){
    	      down2[line,4] = genes.sep.down[[line]][1]
    	    }
    	    else{
    	      down2[line,4] = genes.sep.down[[line]][2]
    	    }
    	  }
    	}
    	num_down<-dim(down)[1]
    	descr<-c(rep("under_expressed",num_down))  # desc stores information of fold changes of each gene
    	down<-cbind(down,descr)
    	colnames(down)[dim(down)[2]]<-"Description"
  	}
  
  	# If the results dont contain under or over differently expressed genes
  	if(dim(up)[1]==0){
  		print("No up-expressed genes found")
  	}
  	if(dim(down)[1]==0){
  		print("No down-expressed genes found")
  	}
  	RES_genes<-rbind(up,down)		# Merge up, down tables
  	GeneSym<-read.delim(paste0("./GeneSymbol_MATCH.txt"),sep="\t",header=TRUE) # Synon
  	GeneSym<-GeneSym[,1:2]
  	RES_ID<-merge(RES_genes,GeneSym,by="ID",all.x=TRUE)
  	RES_ID<-RES_ID[order(RES_ID$fdr_pval,decreasing=FALSE),]
  	if (met2 == "REM"){
  	  RES_ID<-RES_ID[,-8]
  	} else{
  	  RES_ID<-RES_ID[,-5]
  	}
  	write.table(RES_ID,paste0("Meta_analysis_results.txt"),sep="\t",row.names=FALSE)   	## Save in work directory
  }
  
## Save results of p value meta-analysis
  if(met1=="PVALUE"){
  
  	## Save results of meta-analysis
  	# RES<-as.data.frame(DE$meta.analysis_0$pval)
  	# RES<-cbind(RES, as.data.frame(DE$meta.analysis$pval))
    
  	RES<-as.data.frame(DE$meta.analysis$pval)
  	RES<-cbind(RES,DE$meta.analysis$FDR)
  	RES<-cbind(RES,rownames(RES))
  	colnames(RES)<-c("pval","fdr_pval","ID")
  	fc<-DE$limma
  	fc<-fc[,1:2]
  	RES<-Reduce(merge,list(fc,RES))

  	GeneSym<-read.delim(paste0("./GeneSymbol_MATCH.txt"),sep="\t",header=TRUE)
  	GeneSym<-GeneSym[,1:2]
  	RES_2<-merge(RES,GeneSym,by="ID",all.x=TRUE)
  	write.table(RES_2,paste0("All_genes_results.txt"),sep="\t",row.names=FALSE)   	# Save all results
 
	RES<-RES[complete.cases(RES), ]	# Remove rows with missing values	
	RES$fdr_pval = p.adjust(as.numeric(RES$pval), method = "fdr")
  	RES<-RES[RES$pval<=threshold,]		# Filter genes by p value threshold
  	up<-RES[RES$FoldChange>0,]		# Create a matrix with up-expressed genes
  	up2 = up
  	up2[,1] = as.character(up2[,1])
  	genes.sep.up =  strsplit(up2[,1], "///", fixed = T)
  	for (line in 1:length(up2[,1])){
  	  if (length(genes.sep.up[[line]]) > 1){
  	    if (!grepl("-", genes.sep.up[[line]][1], fixed = T) && !grepl("LOC", genes.sep.up[[line]][1], fixed = T)){
  	      up2[line,1] = genes.sep.up[[line]][1]
  	    }
  	    else{
  	      up2[line,1] = genes.sep.up[[line]][2]
  	    }
  	  }
  	}
  	num_up<-dim(up)[1]
  	desc<-c(rep("over_expressed",num_up))
  	up<-cbind(up,desc); colnames(up)[dim(up)[2]]<-"Description"
	
  	down<-RES[RES$FoldChange<0,]	# Create a matrix with up-expressed genes
  	down2 = down
  	down2[,1] = as.character(down2[,1])
  	genes.sep.down =  strsplit(down2[,1], "///", fixed = T)
  	for (line in 1:length(down2[,1])){
  	  if (length(genes.sep.down[[line]]) > 1){
  	    if (!grepl("-", genes.sep.down[[line]][1], fixed = T) && !grepl("LOC", genes.sep.down[[line]][1], fixed = T)){
  	      down2[line,1] = genes.sep.down[[line]][1]
  	    }
  	    else{
  	      down2[line,1] = genes.sep.down[[line]][2]
  	    }
  	  }
  	}
  	num_down<-dim(down)[1]
  	descr<-c(rep("under_expressed",num_down))
  	down<-cbind(down,descr)
  	colnames(down)[dim(down)[2]]<-"Description"
  
  	## If the results dont contain under or over differently expressed genes
  	if(dim(up)[1]==0){
  		print("No up-expressed genes found")
  	}
  	if(dim(down)[1]==0){
  		print("No down-expressed genes found")
  	}
  	RES_genes<-rbind(up,down)
  	rownames(RES_genes)<-RES_genes[,1]
  	
  	GeneSym<-read.delim(paste0("./GeneSymbol_MATCH.txt"),sep="\t",header=TRUE)
  	GeneSym<-GeneSym[,1:2]
  	RES_ID<-merge(RES_genes,GeneSym,by="ID",all.x=TRUE)
  	RES_ID<-RES_ID[order(RES_ID$pval,decreasing=FALSE),]
  	RES_ID<-RES_ID[,-5]
  	
  	write.table(RES_ID,paste0("Meta_analysis_results.txt"),sep="\t",row.names=FALSE)   	## Save in work directory
  	
  }
  return(RES_genes)
}
#############################################################

#############################################################
UpSelf<-function(
# Function to upload local datasets
  nameData,		# Vector with File names of the datasets
  plat,			# platform of the datasets
  geoIDs){		# vector with GEO Identifiers (if there are)
  
  counter.txt <- grep("txt$",nameData)
  counter.tsv <- grep("tsv$",nameData)
  sum.numberData <- length(counter.txt) + length(counter.tsv)
  if(((length(counter.txt)>0) || (length(counter.tsv)>0)) && (sum.numberData == length(nameData))){

   for(ii in 1:length(nameData)){ 
		data<-read.delim(nameData[ii],sep="\t",header=TRUE)
		cl<-as.character(data[1,2:dim(data)[2]])
		data<-data[-1,]
		dset<-data[,2:dim(data)[2]]
  
		ex <-dset  # Normalization and log2 transformation
    	qx <- as.numeric(quantile(ex, c(0., 0.25, 0.5, 0.75, 0.99, 1.0), na.rm=T))
    	LogC <- (qx[5] > 100) ||
            (qx[6]-qx[1] > 50 && qx[2] > 0) ||
            (qx[2] > 0 && qx[2] < 1 && qx[4] > 1 && qx[4] < 2)
    	if (LogC){
    		dset <- log2(ex) 
    	}
		
		dset<-cbind(data[,1],dset)
  
		colnames(dset)[1]<-plat[ii]

		IDfile<-read.delim(paste0(plat[ii],".txt"),sep="\t",header=TRUE) # Read from folder
		colnames(IDfile)[1]<-plat[ii]
		dset<-Reduce(merge,list(IDfile[,1:2],dset))
		dset<-dset[,-1]
		dset<-dset[!duplicated(dset),]  
	
		
		if (nrow(dset) < nrow(data)/100) {
		  errors<-paste0("ERROR: ", nameData[ii], " contains less than 10 % matches with ", plat[ii], " platform. Are you sure this is the correct platform?")
		  write(errors,paste0("ERROR.txt"),sep="\n",append=TRUE)
		  print(errors)
		}
		else {
		  data<-data[data$ID!="",]; data<-data[is.na(data$ID)!=TRUE,] # Processing of Missing values in geneID COMPROBAR FACTORES
		  drow<-c("NA",cl); dset<-rbind(drow,dset); coln<-"ID"; tam<-dim(dset)[2] # Format data for metaDE
		  for(f in 1:(tam-1)){ 
		    coln<-c(coln,paste0(nameData[ii],sep="","_",f))
		  }
		  colnames(dset)<-coln
		  x<-gsub(".txt","",gsub(".tsv","",nameData[ii]))
		  x<-paste0(x,"processed",sep="")
		  geoIDs<-c(geoIDs,x)
		  x.save<-paste0(x,".txt",sep="")
		  write.table(dset,file=x.save,sep="\t")
		} 
		}
  

		return(geoIDs)
	} else{
		errors<-c("ERROR: Some file name(s) doesn't end with '.txt' or '.tsv'")
		write(errors,paste0("ERROR.txt"),sep="\n",append=TRUE)
		print(errors)
	}
} 



